<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;

class Controller extends BaseController
{
    public function index()
    {
      return view('welcome');
    }
     public function tambahdata()
    {
      return view('tambahdata');
    }
     public function editdata()
    {
      return view('edit');
    }
     public function hapusdata()
    {
      return view('hapus');
    }
     public function lihat()
    {
      return view('lihat');
    }
}
